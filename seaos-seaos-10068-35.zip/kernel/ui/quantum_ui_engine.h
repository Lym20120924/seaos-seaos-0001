#ifndef QUANTUM_UI_ENGINE_H
#define QUANTUM_UI_ENGINE_H

#include <stdint.h>

// SeaOS 113Hz - Quantum UI Engine Header
// Internal Version: 10068.35

#define SEAOS_VERSION_MAJOR 113
#define SEAOS_VERSION_MINOR 0
#define SEAOS_INTERNAL_BUILD 10068.35f

// Quantum UI context
typedef struct {
    uint16_t version_major;
    uint16_t version_minor;
    float internal_build;
    uint8_t quantum_enabled;
    uint8_t holographic_mode;
    uint8_t neural_animations;
    float fps;
    float quantum_efficiency;
    float neural_learning_level;
    float quantum_optimization;
    float system_activity;
    float time;
    uint32_t icon_count;
    struct quantum_icon* icons;
    uint8_t transition_active;
    float transition_progress;
} quantum_ui_context_t;

// Quantum color system
typedef struct {
    float quantum_red;
    float quantum_green;
    float quantum_blue;
    float quantum_alpha;
    float temporal_shift;
    float dimensional_depth;
} quantum_color_t;

// Quantum point
typedef struct {
    float x, y, z;
    float quantum_uncertainty;
} quantum_point_t;

// Quantum transform
typedef struct {
    float scale;
    float rotation;
    float holographic_depth;
    float quantum_glow;
} quantum_transform_t;

// Quantum icon
typedef struct quantum_icon {
    uint32_t id;
    char name[64];
    quantum_point_t position;
    quantum_color_t color;
    float frequency;
    float phase;
    float morph_factor;
    float quantum_glow;
    float holographic_depth;
    float shape_complexity;
    uint8_t morphing_enabled;
} quantum_icon_t;

// Notification types
typedef enum {
    NOTIFICATION_INFO,
    NOTIFICATION_WARNING,
    NOTIFICATION_ERROR,
    NOTIFICATION_SUCCESS,
    NOTIFICATION_QUANTUM_ALERT
} quantum_notification_type_t;

// Quantum notification
typedef struct {
    char title[128];
    char message[512];
    quantum_notification_type_t type;
    quantum_point_t position;
    uint64_t creation_time;
    float quantum_glow;
    float holographic_depth;
    float neural_importance;
    struct dimensional_animation entrance_animation;
} quantum_notification_t;

// Function declarations
void quantum_ui_init(void);
void quantum_ui_setup_elements(void);
void quantum_ui_render_frame(void);
void quantum_render_living_background(float time);
void quantum_render_morphing_icons(void);
void dimensional_effects_render(float time);
void neural_animation_update(struct neural_animator* animator, float time);
void quantum_notification_create(const char* title, const char* message, quantum_notification_type_t type);
float calculate_quantum_efficiency(void);
void quantum_ui_shutdown(void);

#endif