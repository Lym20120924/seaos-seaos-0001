#ifndef HOLOGRAPHIC_RENDERER_H
#define HOLOGRAPHIC_RENDERER_H

#include <stdint.h>

// SeaOS 113Hz - Holographic Rendering System
// Creates true 3D holographic effects in the UI

typedef struct {
    float depth_layers[16];
    float holographic_intensity;
    float light_refraction;
    float quantum_interference;
    float efficiency;
    uint8_t enabled;
} holographic_display_t;

typedef struct {
    float amplitude;
    float frequency;
    float phase;
    uint8_t quantum_interference;
} ocean_wave_params_t;

typedef struct {
    float intensity;
    float frequency;
    float phase;
    uint8_t quantum_tunneling;
} dimensional_fold_params_t;

// Holographic rendering functions
void holographic_display_init(holographic_display_t* display);
void holographic_render_elements(holographic_display_t* display);
void holographic_display_cleanup(holographic_display_t* display);
void render_quantum_wave_layer(ocean_wave_params_t* waves, quantum_color_t* color, int layer);
void render_neural_network_overlay(float time);
void render_quantum_particles(float time);
void apply_holographic_depth(void);
void render_quantum_field_distortions(float time);
void render_dimensional_rift(float progress);

#endif