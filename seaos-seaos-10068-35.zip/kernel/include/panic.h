#ifndef PANIC_H
#define PANIC_H

void kernel_panic(const char* message);

#endif