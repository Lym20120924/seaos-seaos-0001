#ifndef NEURAL_ANIMATION_ENGINE_H
#define NEURAL_ANIMATION_ENGINE_H

#include <stdint.h>

// SeaOS 113Hz - Neural Animation Engine
// AI-driven animation system that learns and adapts

#define MAX_NEURAL_ANIMATIONS 512
#define MAX_LEARNED_PATTERNS 64

// Animation types
typedef enum {
    ANIMATION_TYPE_FADE = 1,
    ANIMATION_TYPE_SLIDE = 2,
    ANIMATION_TYPE_SCALE = 3,
    ANIMATION_TYPE_ROTATION = 4,
    ANIMATION_TYPE_MORPH = 5,
    ANIMATION_TYPE_WARP = 6,
    ANIMATION_TYPE_QUANTUM_TUNNEL = 7,
    ANIMATION_TYPE_DIMENSIONAL_FOLD = 8
} animation_type_t;

// Easing types
typedef enum {
    EASING_LINEAR = 0,
    EASING_QUANTUM_SMOOTH = 1,
    EASING_NEURAL_CURVE = 2,
    EASING_DIMENSIONAL_WARP = 3,
    EASING_HOLOGRAPHIC_SPIRAL = 4,
    EASING_QUANTUM_PULSE = 5,
    EASING_ELASTIC_QUANTUM = 6,
    EASING_BOUNCE_NEURAL = 7
} easing_type_t;

// Neural animation structure
typedef struct {
    uint32_t id;
    animation_type_t type;
    float start_value;
    float end_value;
    float current_value;
    float progress;
    float duration;
    float start_time;
    easing_type_t easing_type;
    uint8_t user_interrupted;
    uint8_t quantum_enabled;
    
    // Quantum properties
    float frequency;
    float phase;
    float quantum_coherence;
} neural_animation_t;

// Animation pattern (learned)
typedef struct {
    char name[64];
    animation_type_t type;
    float default_duration;
    float average_duration;
    easing_type_t easing_function;
    uint8_t quantum_enabled;
    float user_preference_score;
    uint32_t usage_count;
    uint32_t interruption_count;
    float total_duration;
} animation_pattern_t;

// Neural animator
typedef struct {
    neural_animation_t animations[MAX_NEURAL_ANIMATIONS];
    uint32_t animation_count;
    float learning_rate;
    float adaptation_factor;
} neural_animator_t;

// Neural learning data
typedef struct {
    void* duration_network;
    void* easing_network;
    void* pattern_network;
    void* preference_network;
    
    uint32_t total_interactions;
    float average_preference_score;
    float adaptation_level;
} neural_learning_data_t;

// Dimensional animation
typedef struct {
    uint8_t type;
    float duration;
    uint8_t quantum_resonance;
    uint8_t quantum_tunneling;
} dimensional_animation_t;

// Animation types for dimensional effects
#define DIMENSIONAL_FOLD_IN     1
#define DIMENSIONAL_FOLD_OUT    2
#define DIMENSIONAL_PHASE_IN    3
#define DIMENSIONAL_PHASE_OUT   4

// Function declarations
void neural_animation_init(neural_animator_t* animator);
void neural_animation_cleanup(neural_animator_t* animator);
neural_animation_t* create_neural_animation(animation_type_t type, float start_value, float end_value);
void neural_animation_step(neural_animation_t* anim, float time);

// Easing functions
float apply_easing_function(float progress, easing_type_t easing);
float quantum_smooth_step(float progress, float smoothness);
float neural_easing_curve(float progress);
float dimensional_warp_easing(float progress);
float holographic_spiral_easing(float progress);
float quantum_pulse_easing(float progress);
float elastic_quantum_easing(float progress);
float bounce_neural_easing(float progress);

// Neural prediction functions
float neural_predict_optimal_duration(neural_animation_t* anim);
easing_type_t neural_predict_optimal_easing_type(neural_animation_t* anim);
float neural_predict_optimal_easing(neural_animation_t* anim);

// Learning functions
void neural_learn_from_interruption(neural_animation_t* anim);
void neural_learn_from_completed_animation(neural_animation_t* anim);
void neural_save_learning_data(void);

// Quantum effects
float apply_quantum_animation_effects(neural_animation_t* anim, float progress, float time);

// Icon prediction functions (for compatibility)
float neural_predict_icon_relevance(struct quantum_icon* icon);
float neural_get_icon_usage_frequency(struct quantum_icon* icon);
float neural_calculate_icon_relevance(struct quantum_icon* icon, float time);

// Helper functions
animation_pattern_t* find_pattern_by_type(animation_type_t type);
float get_pattern_default_duration(animation_type_t type);

// Neural network functions (placeholders)
void* neural_network_create(int input_size, int hidden_size, int output_size);
float neural_network_predict(void* network, float* inputs);
float* neural_network_predict_multi(void* network, float* inputs);
void neural_network_destroy(void* network);

#endif