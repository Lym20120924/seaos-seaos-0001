#ifndef DIMENSIONAL_UI_EFFECTS_H
#define DIMENSIONAL_UI_EFFECTS_H

#include <stdint.h>

// SeaOS 113Hz - Dimensional UI Effects
// Revolutionary effects that transcend 2D interfaces

#define MAX_QUANTUM_FIELDS 64

// Quantum field types
typedef enum {
    FIELD_TYPE_BASE_REALITY,
    FIELD_TYPE_QUANTUM_FOLD,
    FIELD_TYPE_DIMENSIONAL_RIFT,
    FIELD_TYPE_TEMPORAL_DISTORTION,
    FIELD_TYPE_REALITY_WARP,
    FIELD_TYPE_QUANTUM_TUNNEL,
    FIELD_TYPE_DIMENSIONAL_PHASE
} quantum_field_type_t;

// Dimensional transition types
typedef enum {
    TRANSITION_QUANTUM_FOLD,
    TRANSITION_DIMENSIONAL_RIFT,
    TRANSITION_TEMPORAL_SHIFT,
    TRANSITION_REALITY_WARP,
    TRANSITION_QUANTUM_TUNNEL,
    TRANSITION_DIMENSIONAL_PHASE
} dimensional_transition_type_t;

// Quantum rectangle
typedef struct {
    float x, y;
    float width, height;
} quantum_rect_t;

// Quantum field
typedef struct {
    uint32_t id;
    quantum_field_type_t type;
    quantum_rect_t bounds;
    float strength;
    float frequency;
    float phase;
    uint8_t dimensional_layer;
    uint8_t active;
    float duration;
    float creation_time;
} quantum_field_t;

// Dimensional window
typedef struct {
    quantum_point_t position;
    float width, height;
    uint8_t dimensional_layer;
    float quantum_coherence;
} dimensional_window_t;

// Dimensional engine
typedef struct {
    float reality_distortion_level;
    uint8_t quantum_tunneling_enabled;
    float temporal_flow_rate;
    uint8_t dimensional_layers;
} dimensional_engine_t;

// Effect structures
typedef struct {
    float center_x, center_y;
    float intensity;
    float frequency;
    float duration;
    uint8_t quantum_tunneling;
} quantum_fold_t;

typedef struct {
    float start_x, start_y;
    float end_x, end_y;
    float width;
    float energy;
    float dimensional_depth;
} dimensional_rift_t;

typedef struct {
    float time_dilation;
    float temporal_frequency;
    float duration;
    float quantum_coherence;
} temporal_shift_t;

typedef struct {
    float distortion_strength;
    float warp_frequency;
    float reality_coherence;
    uint8_t dimensional_layers;
} reality_warp_t;

typedef struct {
    float entry_x, entry_y;
    float tunnel_radius;
    float tunnel_depth;
    float quantum_probability;
    float tunneling_frequency;
} quantum_tunnel_t;

typedef struct {
    float phase_shift_rate;
    float dimensional_frequency;
    float phase_coherence;
    uint8_t quantum_entanglement;
} dimensional_phase_t;

// Function declarations
void dimensional_ui_effects_init(void);
void create_base_reality_field(void);
void dimensional_window_transition(dimensional_window_t* window, dimensional_transition_type_t transition);

// Transition implementations
void execute_quantum_fold_transition(dimensional_window_t* window);
void execute_dimensional_rift_transition(dimensional_window_t* window);
void execute_temporal_shift_transition(dimensional_window_t* window);
void execute_reality_warp_transition(dimensional_window_t* window);
void execute_quantum_tunnel_transition(dimensional_window_t* window);
void execute_dimensional_phase_transition(dimensional_window_t* window);

// Field management
quantum_field_t* create_quantum_field(quantum_field_type_t type);
void update_quantum_fields(float delta_time);
void render_dimensional_effects(void);

// Cleanup
void dimensional_ui_effects_cleanup(void);
float quantum_get_time(void);

#endif