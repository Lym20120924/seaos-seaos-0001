#ifndef QUANTUM_PARTICLE_SYSTEM_H
#define QUANTUM_PARTICLE_SYSTEM_H

#include <stdint.h>

// SeaOS 113Hz - Quantum Particle System
// Advanced particle effects with quantum physics simulation

#define MAX_QUANTUM_PARTICLES 10000

typedef struct {
    float x, y, z;
    float velocity_x, velocity_y, velocity_z;
    float quantum_state;
    float life_time;
    float energy;
    quantum_color_t color;
    uint8_t quantum_entangled;
} quantum_particle_t;

typedef struct {
    quantum_particle_t particles[MAX_QUANTUM_PARTICLES];
    uint32_t particle_count;
    float quantum_field_strength;
    float temporal_distortion;
    uint8_t quantum_tunneling_enabled;
} quantum_particle_system_t;

typedef struct {
    float center_x, center_y;
    float intensity;
    float frequency;
    uint8_t quantum_resonance;
} quantum_ripple_t;

// Particle system functions
void quantum_particle_init(quantum_particle_system_t* system);
void quantum_particle_render(quantum_particle_system_t* system);
void quantum_particle_cleanup(quantum_particle_system_t* system);
void quantum_create_ripple(quantum_ripple_t* ripple);
void quantum_create_transition_particles(dimensional_fold_params_t* fold);

#endif